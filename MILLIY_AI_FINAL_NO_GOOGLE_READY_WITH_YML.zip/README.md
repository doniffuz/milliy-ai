# MILLIY AI — Android build

Bu versiya Google/Firebase login ishlatmaydi. Oddiy **ism + email + parol** orqali ro‘yxatdan o‘tish va kirish ishlatiladi.

- Birinchi ro‘yxatdan o‘tgan foydalanuvchi: **ID 1 + admin**.
- Keyingi foydalanuvchilar: **user**.
- Ovoz: speech-to-text + AI javobini TTS orqali o‘qish.
- Rasm/fayl yuborish qo‘llab-quvvatlanadi.
- Android `minSdk=24`, `compileSdk=36`, `NDK=27.0.12077973`.
- GitHub Actions release APK yaratadi.

## GitHub

Repository root ichida quyidagilar bo‘lishi kerak:

```text
pubspec.yaml
lib/main.dart
android/
.github/workflows/main.yml
backend/
```

`Actions → Build MILLIY AI → Run workflow` orqali build boshlanadi.

## Backend manzili

GitHub repository `Settings → Secrets and variables → Actions → Variables` ichida:

```text
API_BASE_URL = https://sizning-domeningiz/api
```

qo‘yiladi. HTTPS ishlatish tavsiya qilinadi.
