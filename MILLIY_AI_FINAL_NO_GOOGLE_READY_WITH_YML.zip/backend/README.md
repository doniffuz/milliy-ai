# MILLIY AI backend

`api.php` oddiy email/parol autentifikatsiyasi, sessiya tokenlari va AI proxy endpointlarini beradi.

## Muhit o‘zgaruvchilari

`.env.example` ni server sozlamalariga moslang:

- `DB_FILE` — SQLite fayli
- `AI_API_URL` — AI server endpointi
- `MIN_APP_VERSION` — majburiy minimal APK versiyasi
- `LATEST_APP_VERSION` — eng yangi versiya
- `APK_URL` — yangi APK manzili
- `FORCE_UPDATE` — `true`/`false`

PHP serverda SQLite va cURL yoqilgan bo‘lishi kerak.
