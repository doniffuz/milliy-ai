<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

$dbFile = getenv('DB_FILE') ?: __DIR__ . '/data.sqlite';
$aiUrl = trim((string)(getenv('AI_API_URL') ?: ''));
$minVersion = getenv('MIN_APP_VERSION') ?: '1.0.0';
$latestVersion = getenv('LATEST_APP_VERSION') ?: $minVersion;
$apkUrl = getenv('APK_URL') ?: '';
$forceUpdate = filter_var(getenv('FORCE_UPDATE') ?: 'false', FILTER_VALIDATE_BOOLEAN);

$db = new PDO('sqlite:' . $dbFile, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$db->exec('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT "user", status TEXT NOT NULL DEFAULT "active", created_at TEXT NOT NULL, last_seen TEXT NOT NULL)');
$db->exec('CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires_at INTEGER NOT NULL)');

function out(array $data, int $status = 200): never { http_response_code($status); echo json_encode($data, JSON_UNESCAPED_UNICODE); exit; }
function body(): array { $x = json_decode(file_get_contents('php://input'), true); return is_array($x) ? $x : []; }
function authUser(PDO $db): array {
  $h = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
  if (!preg_match('/^Bearer\s+(.+)$/i', $h, $m)) out(['error'=>'Token kerak'],401);
  $hash = hash('sha256', trim($m[1]));
  $q = $db->prepare('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.status="active"');
  $q->execute([$hash, time()]); $u=$q->fetch(PDO::FETCH_ASSOC);
  if (!$u) out(['error'=>'Sessiya tugagan yoki noto‘g‘ri'],401);
  return $u;
}
function newToken(PDO $db, int $userId): string {
  $raw = bin2hex(random_bytes(32)); $hash=hash('sha256',$raw);
  $q=$db->prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)'); $q->execute([$hash,$userId,time()+60*60*24*30]);
  return $raw;
}
function publicUser(array $u): array { return ['id'=>(int)$u['id'],'name'=>$u['name'],'email'=>$u['email'],'role'=>$u['role'],'status'=>$u['status']]; }

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/';
$path = rtrim($path, '/');
if (preg_match('#/api(?:\.php)?(?:/|$)#', $path, $m, PREG_OFFSET_CAPTURE)) {
  $pos = $m[0][1];
  $prefix = $m[0][0];
  $path = substr($path, $pos + strlen($prefix) - (str_ends_with($prefix, '/') ? 1 : 0));
  if ($path === '' || $path === false) $path = '/';
  if ($path[0] !== '/') $path = '/'.$path;
}

if ($_SERVER['REQUEST_METHOD']==='POST' && $path==='/auth/register') {
  $b=body(); $name=trim((string)($b['name']??'')); $email=strtolower(trim((string)($b['email']??''))); $password=(string)($b['password']??'');
  if ($name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($password)<6) out(['error'=>'Ism, to‘g‘ri email va kamida 6 belgili parol kerak'],422);
  $exists=$db->prepare('SELECT id FROM users WHERE email=?'); $exists->execute([$email]); if($exists->fetch()) out(['error'=>'Bu email allaqachon ro‘yxatdan o‘tgan'],409);
  $count=(int)$db->query('SELECT COUNT(*) FROM users')->fetchColumn();
  $role=$count===0 ? 'admin' : 'user';
  $now=date('c'); $q=$db->prepare('INSERT INTO users(name,email,password_hash,role,status,created_at,last_seen) VALUES(?,?,?,?,?,?,?)'); $q->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT),$role,'active',$now,$now]);
  $id=(int)$db->lastInsertId(); $u=$db->query('SELECT * FROM users WHERE id='.$id)->fetch(PDO::FETCH_ASSOC); $token=newToken($db,$id);
  out(['token'=>$token,'user'=>publicUser($u)],201);
}

if ($_SERVER['REQUEST_METHOD']==='POST' && $path==='/auth/login') {
  $b=body(); $email=strtolower(trim((string)($b['email']??''))); $password=(string)($b['password']??'');
  $q=$db->prepare('SELECT * FROM users WHERE email=?'); $q->execute([$email]); $u=$q->fetch(PDO::FETCH_ASSOC);
  if(!$u || !password_verify($password,$u['password_hash'])) out(['error'=>'Email yoki parol noto‘g‘ri'],401);
  $db->prepare('UPDATE users SET last_seen=? WHERE id=?')->execute([date('c'),$u['id']]); $token=newToken($db,(int)$u['id']);
  out(['token'=>$token,'user'=>publicUser($u)]);
}

if ($_SERVER['REQUEST_METHOD']==='GET' && $path==='/me') { $u=authUser($db); out(publicUser($u)); }

if ($_SERVER['REQUEST_METHOD']==='GET' && $path==='/app-config') {
  out(['min_version'=>$minVersion,'latest_version'=>$latestVersion,'apk_url'=>$apkUrl,'force_update'=>$forceUpdate]);
}

if ($_SERVER['REQUEST_METHOD']==='POST' && $path==='/chat') {
  $u=authUser($db); $message=trim((string)($_POST['message']??''));
  if($message==='' && empty($_FILES['image']) && empty($_FILES['file'])) out(['error'=>'Savol yoki fayl yuboring'],422);
  if($aiUrl==='') out(['error'=>'AI_API_URL serverda sozlanmagan'],503);
  $payload=['message'=>$message,'user_id'=>(string)$u['id']];
  foreach(['image','file'] as $field){ if(isset($_FILES[$field]) && is_uploaded_file($_FILES[$field]['tmp_name'])) { $payload[$field]=new CURLFile($_FILES[$field]['tmp_name'], $_FILES[$field]['type'] ?: 'application/octet-stream', $_FILES[$field]['name']); }}
  $ch=curl_init($aiUrl); curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_POSTFIELDS=>$payload,CURLOPT_TIMEOUT=>120]); $res=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
  if($res===false || $code<200 || $code>=300) out(['error'=>'AI serveriga ulanishda xato'],502);
  $decoded=json_decode($res,true); if(is_array($decoded) && isset($decoded['answer'])) out(['answer'=>(string)$decoded['answer']]);
  out(['answer'=>(string)$res]);
}

out(['error'=>'Endpoint topilmadi'],404);
