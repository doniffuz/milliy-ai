import 'dart:convert';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;

const apiBaseUrl = String.fromEnvironment(
  'API_BASE_URL',
  defaultValue: 'https://YOUR-BACKEND.example/api',
);

void main() => runApp(const MilliyAI());

class MilliyAI extends StatelessWidget {
  const MilliyAI({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Milliy AI',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const AuthGate(),
    );
  }
}

class Api {
  static Future<Map<String, dynamic>> register(String name, String email, String password) async {
    final r = await http.post(
      Uri.parse('$apiBaseUrl/auth/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'name': name, 'email': email, 'password': password}),
    );
    return _jsonOrThrow(r, 'Ro‘yxatdan o‘tishda xato');
  }

  static Future<Map<String, dynamic>> login(String email, String password) async {
    final r = await http.post(
      Uri.parse('$apiBaseUrl/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );
    return _jsonOrThrow(r, 'Kirishda xato');
  }

  static Future<Map<String, dynamic>> me(String token) async {
    final r = await http.get(
      Uri.parse('$apiBaseUrl/me'),
      headers: {'Authorization': 'Bearer $token'},
    );
    return _jsonOrThrow(r, 'Profil serverdan olinmadi');
  }

  static Future<String> chat({
    required String token,
    required String text,
    String? imagePath,
    String? filePath,
  }) async {
    final req = http.MultipartRequest('POST', Uri.parse('$apiBaseUrl/chat'));
    req.headers['Authorization'] = 'Bearer $token';
    req.fields['message'] = text;
    if (imagePath != null) {
      req.files.add(await http.MultipartFile.fromPath('image', imagePath));
    }
    if (filePath != null) {
      req.files.add(await http.MultipartFile.fromPath('file', filePath));
    }
    final res = await req.send();
    final body = await res.stream.bytesToString();
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('AI server xatosi: ${res.statusCode}');
    }
    final data = jsonDecode(body) as Map<String, dynamic>;
    return (data['answer'] ?? '').toString();
  }

  static Future<Map<String, dynamic>> appConfig() async {
    final r = await http.get(Uri.parse('$apiBaseUrl/app-config'));
    return _jsonOrThrow(r, 'Config olinmadi');
  }

  static Map<String, dynamic> _jsonOrThrow(http.Response r, String fallback) {
    Map<String, dynamic> data = {};
    try {
      final decoded = jsonDecode(r.body);
      if (decoded is Map<String, dynamic>) data = decoded;
    } catch (_) {}
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception((data['error'] ?? fallback).toString());
    }
    return data;
  }
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  bool loading = true;
  String? token;
  Map<String, dynamic>? user;
  String? error;

  @override
  void initState() { super.initState(); _restore(); }

  Future<void> _restore() async {
    final p = await SharedPreferences.getInstance();
    final t = p.getString('token');
    if (t != null && t.isNotEmpty) {
      try {
        user = await Api.me(t);
        token = t;
      } catch (_) {
        await p.remove('token');
      }
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _auth(bool register) async {
    final result = await showDialog<Map<String, String>>(
      context: context,
      builder: (_) => AuthDialog(register: register),
    );
    if (result == null) return;

    setState(() { loading = true; error = null; });
    try {
      final data = register
          ? await Api.register(result['name']!, result['email']!, result['password']!)
          : await Api.login(result['email']!, result['password']!);
      token = (data['token'] ?? '').toString();
      user = Map<String, dynamic>.from(data['user'] as Map);
      final p = await SharedPreferences.getInstance();
      await p.setString('token', token!);
    } catch (e) {
      error = e.toString().replaceFirst('Exception: ', '');
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (token != null && user != null) return Home(token: token!, user: user!);
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.auto_awesome, size: 76),
            const SizedBox(height: 12),
            const Text('MILLIY AI', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            const Text('Oddiy va xavfsiz akkaunt orqali kiring', textAlign: TextAlign.center),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: loading ? null : () => _auth(false),
              icon: const Icon(Icons.login),
              label: const Text('Kirish'),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: loading ? null : () => _auth(true),
              icon: const Icon(Icons.person_add),
              label: const Text('Ro‘yxatdan o‘tish'),
            ),
            if (error != null) Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Text(error!, textAlign: TextAlign.center),
            ),
          ]),
        ),
      ),
    );
  }
}

class AuthDialog extends StatefulWidget {
  final bool register;
  const AuthDialog({super.key, required this.register});
  @override State<AuthDialog> createState() => _AuthDialogState();
}

class _AuthDialogState extends State<AuthDialog> {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  bool obscure = true;

  @override
  void dispose() {
    name.dispose(); email.dispose(); password.dispose(); super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.register ? 'Ro‘yxatdan o‘tish' : 'Kirish'),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (widget.register) TextField(controller: name, textInputAction: TextInputAction.next,
            decoration: const InputDecoration(labelText: 'Ism', prefixIcon: Icon(Icons.person))),
          if (widget.register) const SizedBox(height: 10),
          TextField(controller: email, keyboardType: TextInputType.emailAddress,
            textInputAction: TextInputAction.next,
            decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email))),
          const SizedBox(height: 10),
          TextField(controller: password, obscureText: obscure,
            decoration: InputDecoration(labelText: 'Parol', prefixIcon: const Icon(Icons.lock),
              suffixIcon: IconButton(onPressed: () => setState(() => obscure = !obscure),
                icon: Icon(obscure ? Icons.visibility : Icons.visibility_off)))),
        ]),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Bekor qilish')),
        FilledButton(onPressed: () {
          final n = name.text.trim(); final e = email.text.trim(); final p = password.text;
          if (e.isEmpty || p.length < 6 || (widget.register && n.isEmpty)) return;
          Navigator.pop(context, {'name': n, 'email': e, 'password': p});
        }, child: Text(widget.register ? 'Ro‘yxatdan o‘tish' : 'Kirish')),
      ],
    );
  }
}

class Home extends StatefulWidget {
  final String token;
  final Map<String, dynamic> user;
  const Home({super.key, required this.token, required this.user});
  @override State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final input = TextEditingController();
  final tts = FlutterTts();
  final speech = stt.SpeechToText();
  final picker = ImagePicker();
  final messages = <Map<String, String>>[];
  bool sending = false;
  bool listening = false;
  bool dark = false;
  String? imagePath;
  String? filePath;

  Future<void> send() async {
    final text = input.text.trim();
    if (text.isEmpty && imagePath == null && filePath == null) return;
    setState(() => sending = true);
    try {
      final answer = await Api.chat(token: widget.token, text: text, imagePath: imagePath, filePath: filePath);
      setState(() {
        if (text.isNotEmpty) messages.add({'role': 'user', 'text': text});
        messages.add({'role': 'ai', 'text': answer});
        input.clear(); imagePath = null; filePath = null;
      });
      if (answer.isNotEmpty) await tts.speak(answer);
    } catch (e) {
      setState(() => messages.add({'role': 'ai', 'text': 'Xatolik: $e'}));
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  Future<void> pickImage() async {
    final x = await picker.pickImage(source: ImageSource.gallery);
    if (x != null) setState(() => imagePath = x.path);
  }

  Future<void> pickFile() async {
    final r = await FilePicker.platform.pickFiles();
    if (r != null && r.files.single.path != null) setState(() => filePath = r.files.single.path);
  }

  Future<void> voice() async {
    if (listening) { await speech.stop(); if (mounted) setState(() => listening = false); return; }
    final ok = await speech.initialize();
    if (!ok) return;
    if (mounted) setState(() => listening = true);
    await speech.listen(onResult: (r) {
      input.text = r.recognizedWords;
      input.selection = TextSelection.collapsed(offset: input.text.length);
      if (r.finalResult && mounted) setState(() => listening = false);
    });
  }

  Future<void> settings() async {
    await showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(leading: const Icon(Icons.dark_mode), title: const Text('Dark / Light'),
          onTap: () { setState(() => dark = !dark); Navigator.pop(context); }),
        ListTile(leading: const Icon(Icons.favorite), title: const Text('Qo‘llab-quvvatlash'),
          onTap: () async {
            Navigator.pop(context);
            await launchUrl(Uri.parse('https://example.com/donate'), mode: LaunchMode.externalApplication);
          }),
        ListTile(leading: const Icon(Icons.person), title: Text('ID: ${widget.user['id'] ?? '-'}')),
        ListTile(leading: const Icon(Icons.email), title: Text('${widget.user['email'] ?? ''}')),
      ])),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: ThemeData(useMaterial3: true, brightness: dark ? Brightness.dark : Brightness.light, colorSchemeSeed: Colors.indigo),
      child: Scaffold(
        appBar: AppBar(
          title: const Text('MILLIY AI', style: TextStyle(fontWeight: FontWeight.w800)),
          actions: [
            IconButton(onPressed: settings, icon: const Icon(Icons.settings)),
            IconButton(onPressed: () => setState(messages.clear), icon: const Icon(Icons.add_comment)),
          ],
        ),
        body: Column(children: [
          Expanded(child: messages.isEmpty
            ? const Center(child: Text('Savolingizni yozing yoki ovozli gapiring'))
            : ListView.builder(
                padding: const EdgeInsets.all(12), itemCount: messages.length,
                itemBuilder: (_, i) => Align(
                  alignment: messages[i]['role'] == 'user' ? Alignment.centerRight : Alignment.centerLeft,
                  child: Card(child: Padding(padding: const EdgeInsets.all(12), child: Text(messages[i]['text'] ?? ''))),
                ),
              )),
          if (imagePath != null || filePath != null)
            Padding(padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(children: [
                Text(imagePath != null ? '🖼️ Rasm tanlandi' : '📎 Fayl tanlandi'),
                const Spacer(), IconButton(onPressed: () => setState(() { imagePath = null; filePath = null; }), icon: const Icon(Icons.close)),
              ])),
          SafeArea(child: Padding(padding: const EdgeInsets.all(10), child: Row(children: [
            IconButton(onPressed: pickImage, icon: const Icon(Icons.image_outlined)),
            IconButton(onPressed: pickFile, icon: const Icon(Icons.attach_file)),
            Expanded(child: TextField(controller: input, minLines: 1, maxLines: 5,
              onSubmitted: (_) => send(), decoration: const InputDecoration(hintText: 'Savolingizni yozing...', border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(22))))),),
            IconButton(onPressed: voice, icon: Icon(listening ? Icons.stop_circle : Icons.mic)),
            const SizedBox(width: 2),
            FloatingActionButton.small(onPressed: sending ? null : send,
              child: sending ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.arrow_upward)),
          ]))),
        ]),
      ),
    );
  }
}
