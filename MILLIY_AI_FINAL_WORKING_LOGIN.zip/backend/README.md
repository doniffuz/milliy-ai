# Backend contract

Implement these HTTPS endpoints:

POST /auth/google
GET  /me
POST /chat
GET  /app-config

Admin-only endpoints should verify the server-side admin role, never trust a client-provided ID.

Recommended fields:
users(id, google_sub, email, name, role, status, created_at, last_seen)
app_config(min_version, latest_version, apk_url, force_update)
broadcasts(id, title, body, media_url, created_at, created_by)

The first account should NOT become admin merely because it has ID 1. Bootstrap the administrator once on the server using a verified Google subject/email and an environment secret, then store role=admin in the database.
