import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

const apiBaseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: '');

void main() => runApp(const MilliyAI());

class MilliyAI extends StatelessWidget {
  const MilliyAI({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Milliy AI',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
    home: const AuthGate(),
  );
}

String _hash(String value) => sha256.convert(utf8.encode(value)).toString();

class LocalAuth {
  static const _usersKey = 'milliy_users_v2';
  static const _currentIdKey = 'milliy_current_id_v2';

  static Future<List<Map<String, dynamic>>> users() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_usersKey);
    if (raw == null || raw.isEmpty) return [];
    try {
      return (jsonDecode(raw) as List)
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> _save(List<Map<String, dynamic>> users) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_usersKey, jsonEncode(users));
  }

  static Future<Map<String, dynamic>> register({
    required String name,
    required String email,
    required String password,
  }) async {
    final cleanName = name.trim();
    final cleanEmail = email.trim().toLowerCase();
    if (cleanName.length < 2) throw Exception('Ism kamida 2 ta belgidan iborat bo‘lsin.');
    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(cleanEmail)) {
      throw Exception('Email manzilni to‘g‘ri kiriting.');
    }
    if (password.length < 6) throw Exception('Parol kamida 6 ta belgidan iborat bo‘lsin.');

    final list = await users();
    if (list.any((u) => (u['email'] ?? '').toString().toLowerCase() == cleanEmail)) {
      throw Exception('Bu email bilan akkaunt allaqachon mavjud.');
    }

    final id = list.isEmpty ? 1 : list.map((u) => (u['id'] as num?)?.toInt() ?? 0).reduce((a, b) => a > b ? a : b) + 1;
    final user = <String, dynamic>{
      'id': id,
      'name': cleanName,
      'email': cleanEmail,
      'password': _hash(password),
      'role': id == 1 ? 'admin' : 'user',
      'createdAt': DateTime.now().toIso8601String(),
    };
    list.add(user);
    await _save(list);
    await _setCurrent(id);
    return _public(user);
  }

  static Future<Map<String, dynamic>> login({required String email, required String password}) async {
    final cleanEmail = email.trim().toLowerCase();
    final list = await users();
    for (final u in list) {
      if ((u['email'] ?? '').toString().toLowerCase() == cleanEmail && u['password'] == _hash(password)) {
        await _setCurrent((u['id'] as num).toInt());
        return _public(u);
      }
    }
    throw Exception('Email yoki parol noto‘g‘ri.');
  }

  static Map<String, dynamic> _public(Map<String, dynamic> u) => {
    'id': u['id'], 'name': u['name'], 'email': u['email'], 'role': u['role'], 'createdAt': u['createdAt']
  };

  static Future<void> _setCurrent(int id) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt(_currentIdKey, id);
  }

  static Future<Map<String, dynamic>?> current() async {
    final p = await SharedPreferences.getInstance();
    final id = p.getInt(_currentIdKey);
    if (id == null) return null;
    final list = await users();
    for (final u in list) {
      if ((u['id'] as num?)?.toInt() == id) return _public(u);
    }
    return null;
  }

  static Future<void> logout() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(_currentIdKey);
  }

  static Future<List<Map<String, dynamic>>> allPublic() async => (await users()).map(_public).toList();
}

class Api {
  static bool get enabled => apiBaseUrl.isNotEmpty && !apiBaseUrl.contains('YOUR-BACKEND');

  static Future<String> chat({required String text, String? imagePath, String? filePath}) async {
    if (!enabled) {
      throw Exception('AI server manzili sozlanmagan. Matnli lokal kirish tizimi ishlaydi, AI uchun API_BASE_URL kerak.');
    }
    final req = http.MultipartRequest('POST', Uri.parse('$apiBaseUrl/chat'));
    req.fields['message'] = text;
    if (imagePath != null) req.files.add(await http.MultipartFile.fromPath('image', imagePath));
    if (filePath != null) req.files.add(await http.MultipartFile.fromPath('file', filePath));
    final res = await req.send();
    final body = await res.stream.bytesToString();
    if (res.statusCode < 200 || res.statusCode >= 300) throw Exception('AI server xatosi: ${res.statusCode}');
    return (jsonDecode(body)['answer'] ?? '').toString();
  }
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override State<AuthGate> createState() => _AuthGateState();
}
class _AuthGateState extends State<AuthGate> {
  bool loading = true;
  Map<String, dynamic>? user;
  bool register = false;

  @override
  void initState() { super.initState(); _restore(); }

  Future<void> _restore() async {
    user = await LocalAuth.current();
    if (mounted) setState(() => loading = false);
  }

  void _done(Map<String, dynamic> u) {
    setState(() { user = u; loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (user != null) return Home(user: user!, onLogout: () async { await LocalAuth.logout(); setState(() => user = null); });
    return AuthPage(register: register, onSwitch: () => setState(() => register = !register), onDone: _done);
  }
}

class AuthPage extends StatefulWidget {
  final bool register;
  final VoidCallback onSwitch;
  final ValueChanged<Map<String, dynamic>> onDone;
  const AuthPage({super.key, required this.register, required this.onSwitch, required this.onDone});
  @override State<AuthPage> createState() => _AuthPageState();
}
class _AuthPageState extends State<AuthPage> {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  final confirm = TextEditingController();
  bool busy = false;
  String? error;

  Future<void> submit() async {
    FocusScope.of(context).unfocus();
    setState(() { busy = true; error = null; });
    try {
      if (widget.register) {
        if (password.text != confirm.text) throw Exception('Parollar bir xil emas.');
        final u = await LocalAuth.register(name: name.text, email: email.text, password: password.text);
        widget.onDone(u);
      } else {
        final u = await LocalAuth.login(email: email.text, password: password.text);
        widget.onDone(u);
      }
    } catch (e) {
      setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(
      padding: const EdgeInsets.all(28),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 430),
        child: Column(children: [
          const Icon(Icons.auto_awesome, size: 72),
          const SizedBox(height: 10),
          const Text('MILLIY AI', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text(widget.register ? 'Yangi akkaunt yarating' : 'Akkauntingizga kiring'),
          const SizedBox(height: 28),
          if (widget.register) ...[
            TextField(controller: name, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Ism', prefixIcon: Icon(Icons.person), border: OutlineInputBorder())),
            const SizedBox(height: 12),
          ],
          TextField(controller: email, keyboardType: TextInputType.emailAddress, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email), border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: password, obscureText: true, textInputAction: widget.register ? TextInputAction.next : TextInputAction.done, onSubmitted: (_) => submit(), decoration: const InputDecoration(labelText: 'Parol', prefixIcon: Icon(Icons.lock), border: OutlineInputBorder())),
          if (widget.register) ...[
            const SizedBox(height: 12),
            TextField(controller: confirm, obscureText: true, onSubmitted: (_) => submit(), decoration: const InputDecoration(labelText: 'Parolni tasdiqlang', prefixIcon: Icon(Icons.lock_outline), border: OutlineInputBorder())),
          ],
          if (error != null) ...[
            const SizedBox(height: 14),
            Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error), textAlign: TextAlign.center),
          ],
          const SizedBox(height: 20),
          SizedBox(width: double.infinity, height: 52, child: FilledButton(
            onPressed: busy ? null : submit,
            child: busy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : Text(widget.register ? 'Ro‘yxatdan o‘tish' : 'Kirish'),
          )),
          const SizedBox(height: 10),
          TextButton(onPressed: busy ? null : widget.onSwitch, child: Text(widget.register ? 'Akkauntingiz bormi? Kirish' : 'Akkauntingiz yo‘qmi? Ro‘yxatdan o‘tish')),
        ]),
      ),
    ))),
  );
}

class Home extends StatefulWidget {
  final Map<String, dynamic> user;
  final Future<void> Function() onLogout;
  const Home({super.key, required this.user, required this.onLogout});
  @override State<Home> createState() => _HomeState();
}
class _HomeState extends State<Home> {
  final input = TextEditingController();
  final tts = FlutterTts();
  final speech = stt.SpeechToText();
  final picker = ImagePicker();
  final messages = <Map<String, String>>[];
  bool sending = false, listening = false, dark = false;
  String? imagePath, filePath;

  Future<void> send() async {
    final text = input.text.trim();
    if (text.isEmpty && imagePath == null && filePath == null) return;
    setState(() => sending = true);
    try {
      final answer = await Api.chat(text: text, imagePath: imagePath, filePath: filePath);
      setState(() {
        if (text.isNotEmpty) messages.add({'role': 'user', 'text': text});
        messages.add({'role': 'ai', 'text': answer});
        input.clear(); imagePath = null; filePath = null;
      });
      await tts.speak(answer);
    } catch (e) {
      setState(() => messages.add({'role': 'ai', 'text': '⚠️ $e'}));
    } finally { if (mounted) setState(() => sending = false); }
  }

  Future<void> pickImage() async { final x = await picker.pickImage(source: ImageSource.gallery); if (x != null) setState(() => imagePath = x.path); }
  Future<void> pickFile() async { final r = await FilePicker.platform.pickFiles(); if (r != null && r.files.single.path != null) setState(() => filePath = r.files.single.path); }
  Future<void> voice() async {
    if (listening) { await speech.stop(); setState(() => listening = false); return; }
    final ok = await speech.initialize();
    if (!ok) { setState(() => messages.add({'role': 'ai', 'text': '🎙️ Ovozli kiritish uchun mikrofon ruxsatini bering.'})); return; }
    setState(() => listening = true);
    await speech.listen(onResult: (r) { setState(() { input.text = r.recognizedWords; input.selection = TextSelection.collapsed(offset: input.text.length); if (r.finalResult) listening = false; }); });
  }

  Future<void> settings() async {
    await showModalBottomSheet(context: context, builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
      ListTile(leading: const Icon(Icons.person), title: Text(widget.user['name'] ?? ''), subtitle: Text('ID: ${widget.user['id']} • ${widget.user['role']}')),
      ListTile(leading: const Icon(Icons.dark_mode), title: const Text('Dark / Light'), onTap: () { setState(() => dark = !dark); Navigator.pop(context); }),
      if (widget.user['role'] == 'admin') ListTile(leading: const Icon(Icons.admin_panel_settings), title: const Text('Admin: foydalanuvchilar'), onTap: () async { Navigator.pop(context); await adminUsers(); }),
      ListTile(leading: const Icon(Icons.logout), title: const Text('Akkauntdan chiqish'), onTap: () async { Navigator.pop(context); await widget.onLogout(); }),
    ]));
  }

  Future<void> adminUsers() async {
    final list = await LocalAuth.allPublic();
    if (!mounted) return;
    await showDialog(context: context, builder: (_) => AlertDialog(
      title: Text('Foydalanuvchilar (${list.length})'),
      content: SizedBox(width: double.maxFinite, height: 350, child: ListView.builder(itemCount: list.length, itemBuilder: (_, i) => ListTile(leading: CircleAvatar(child: Text('${list[i]['id']}')), title: Text(list[i]['name']), subtitle: Text(list[i]['email']), trailing: Text(list[i]['role'])))),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Yopish'))],
    ));
  }

  @override
  Widget build(BuildContext context) => Theme(
    data: ThemeData(useMaterial3: true, brightness: dark ? Brightness.dark : Brightness.light, colorSchemeSeed: Colors.indigo),
    child: Scaffold(
      appBar: AppBar(title: const Text('MILLIY AI', style: TextStyle(fontWeight: FontWeight.w800)), actions: [IconButton(onPressed: settings, icon: const Icon(Icons.settings)), IconButton(onPressed: () => setState(messages.clear), icon: const Icon(Icons.add_comment))]),
      body: Column(children: [
        Expanded(child: messages.isEmpty ? const Center(child: Text('Savolingizni yozing yoki ovozli gapiring')) : ListView.builder(padding: const EdgeInsets.all(12), itemCount: messages.length, itemBuilder: (_, i) => Align(alignment: messages[i]['role'] == 'user' ? Alignment.centerRight : Alignment.centerLeft, child: Card(child: Padding(padding: const EdgeInsets.all(12), child: Text(messages[i]['text'] ?? '')))))),
        if (imagePath != null || filePath != null) Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Row(children: [Expanded(child: Text(imagePath != null ? '🖼️ Rasm tanlandi' : '📎 Fayl tanlandi')), IconButton(onPressed: () => setState(() { imagePath = null; filePath = null; }), icon: const Icon(Icons.close))])),
        SafeArea(child: Padding(padding: const EdgeInsets.all(10), child: Row(children: [IconButton(onPressed: sending ? null : pickImage, icon: const Icon(Icons.image_outlined)), IconButton(onPressed: sending ? null : pickFile, icon: const Icon(Icons.attach_file)), Expanded(child: TextField(controller: input, minLines: 1, maxLines: 5, onSubmitted: (_) => send(), decoration: const InputDecoration(hintText: 'Savolingizni yozing...', border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(22))))),), IconButton(onPressed: sending ? null : voice, icon: Icon(listening ? Icons.stop_circle : Icons.mic)), const SizedBox(width: 2), FloatingActionButton.small(onPressed: sending ? null : send, child: sending ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.arrow_upward))]))),
      ]),
    ),
  );
}
