<?php
// Rename to config.php and fill values on your server. Never commit real secrets.
return [
  'db_dsn' => 'mysql:host=127.0.0.1;dbname=milliy_ai;charset=utf8mb4',
  'db_user' => 'milliy_ai',
  'db_pass' => 'CHANGE_ME',
  'jwt_secret' => 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET_64_CHARS',
  'firebase_project_id' => 'milliy-ai',
  // OpenAI-compatible endpoint. Keep the key server-side only.
  'ai_base_url' => 'https://api.openai.com/v1',
  'ai_api_key' => 'CHANGE_ME',
  'ai_model' => 'gpt-4.1-mini',
  // Optional web search provider (server-side only).
  'web_search_url' => '',
  'web_search_key' => '',
  'allowed_origins' => ['*'],
  'rate_limit_per_minute' => 30,
];
