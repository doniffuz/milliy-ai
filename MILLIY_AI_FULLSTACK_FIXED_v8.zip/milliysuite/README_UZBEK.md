# MILLIY AI

Donyor yaratgan MILLIY AI loyihasi.

## Build
GitHub Actions → Build MILLIY AI APK → Run workflow.

`API_BASE_URL` GitHub Actions Secret sifatida beriladi.

## Muhim
AI API kaliti APK ichida saqlanmaydi. Backend serverda saqlanadi.
