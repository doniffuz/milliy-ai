# Xavfsizlik

- `config.php` ni GitHub'ga yuklamang.
- AI va web-search kalitlari faqat serverda bo'lsin.
- Productionda HTTPS majburiy.
- JWT secretni kamida 64 random belgi qiling.
- Admin rolini faqat serverdagi DB orqali bering.
- Rate limiting/reverse proxy (Nginx/Cloudflare) qo'shing.
- CORS'ni productionda `*` emas, ilovangiz domeniga cheklang.
- Foydalanuvchi yuklagan fayllarni serverda tasodifiy nom bilan saqlang va MIME/size tekshiring.
- Audit loglarni muntazam kuzating.
