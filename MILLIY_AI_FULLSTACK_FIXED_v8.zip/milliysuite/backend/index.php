<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
$configFile=__DIR__.'/config.php'; if(!file_exists($configFile)){http_response_code(500);echo json_encode(['error'=>'Server config.php sozlanmagan']);exit;}
$c=require $configFile;
$origin=$_SERVER['HTTP_ORIGIN']??''; if($origin && (in_array('*',$c['allowed_origins'],true)||in_array($origin,$c['allowed_origins'],true))){header('Access-Control-Allow-Origin: '.$origin);} header('Access-Control-Allow-Headers: Content-Type, Authorization'); header('Access-Control-Allow-Methods: POST, GET, OPTIONS'); if($_SERVER['REQUEST_METHOD']==='OPTIONS'){exit;}
try{$pdo=new PDO($c['db_dsn'],$c['db_user'],$c['db_pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);}catch(Throwable $e){http_response_code(500);echo json_encode(['error'=>'Database ulanmagan']);exit;}
function body():array{return json_decode(file_get_contents('php://input'),true)?:[];}
function jwt(array $p,string $secret):string{$h=rtrim(strtr(base64_encode(json_encode(['alg'=>'HS256','typ'=>'JWT'])), '+/','-_'),'=');$b=rtrim(strtr(base64_encode(json_encode($p)), '+/','-_'),'=');$s=rtrim(strtr(base64_encode(hash_hmac('sha256',"$h.$b",$secret,true)), '+/','-_'),'=');return "$h.$b.$s";}
function auth(array $c):?array{$h=$_SERVER['HTTP_AUTHORIZATION']??'';if(!preg_match('/Bearer\s+(.*)/i',$h,$m))return null;$p=explode('.',$m[1]);if(count($p)!==3)return null;$sig=rtrim(strtr(base64_encode(hash_hmac('sha256',$p[0].'.'.$p[1],$c['jwt_secret'],true)), '+/','-_'),'=');if(!hash_equals($sig,$p[2]))return null;$d=json_decode(base64_decode(strtr($p[1],'-_','+/')),true);return is_array($d)&&($d['exp']??0)>time()?$d:null;}
function out($x,int $code=200){http_response_code($code);echo json_encode($x,JSON_UNESCAPED_UNICODE);exit;}
$path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);
if($path==='/v1/health')out(['ok'=>true,'service'=>'MILLIY AI']);
if($path==='/v1/register'){$b=body();$name=trim((string)($b['name']??''));$email=strtolower(trim((string)($b['email']??'')));$pass=(string)($b['password']??'');if($name===''||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($pass)<10)out(['error'=>'Ism, email va kamida 10 belgili parol kerak'],422);$st=$pdo->prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)');try{$st->execute([$name,$email,password_hash($pass,PASSWORD_DEFAULT)]);}catch(Throwable $e){out(['error'=>'Email band yoki maʼlumot noto‘g‘ri'],409);}out(['ok'=>true]);}
if($path==='/v1/login'){$b=body();$st=$pdo->prepare('SELECT * FROM users WHERE email=?');$st->execute([strtolower(trim((string)($b['email']??'')))]);$u=$st->fetch();if(!$u||!password_verify((string)($b['password']??''),$u['password_hash']))out(['error'=>'Email yoki parol noto‘g‘ri'],401);$tok=jwt(['sub'=>(int)$u['id'],'role'=>$u['role'],'exp'=>time()+86400*7],$c['jwt_secret']);out(['token'=>$tok,'user'=>['id'=>$u['id'],'name'=>$u['name'],'email'=>$u['email'],'role'=>$u['role']]]);}
$user=auth($c); if(!$user)out(['error'=>'Avtorizatsiya talab qilinadi'],401);
if($path==='/v1/chat'){
 $b=body();$msg=trim((string)($b['message']??''));$history=$b['history']??[];$system='Siz MILLIY AI, Donyor yaratgan o‘zbekcha AI yordamchisiz. Javoblarni aniq, foydali va imkon qadar tez bering. Noma’lum faktni uydirmang. Zarur bo‘lsa foydalanuvchidan aniqlik so‘rang.';
 $messages=[['role'=>'system','content'=>$system]];foreach(array_slice($history,-20) as $h){$messages[]=['role'=>($h['user']??false)?'user':'assistant','content'=>(string)($h['text']??'')];}if($msg!=='')$messages[]=['role'=>'user','content'=>$msg];
 $payload=json_encode(['model'=>$c['ai_model'],'messages'=>$messages,'temperature'=>0.2]);$ch=curl_init(rtrim($c['ai_base_url'],'/').'/chat/completions');curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$c['ai_api_key'],'Content-Type: application/json'],CURLOPT_POSTFIELDS=>$payload,CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>40]);$raw=curl_exec($ch);$err=curl_error($ch);$status=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);if($err||$status<200||$status>=300)out(['error'=>'AI server bilan ulanishda xato'],502);$d=json_decode($raw,true);$answer=$d['choices'][0]['message']['content']??'AI javob qaytarmadi.';out(['answer'=>$answer]);
}
out(['error'=>'Endpoint topilmadi'],404);
