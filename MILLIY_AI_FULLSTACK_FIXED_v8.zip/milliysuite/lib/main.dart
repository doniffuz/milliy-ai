
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

const apiBaseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: '');

void main() => runApp(const MilliyAI());

class Message {
  final String text;
  final bool user;
  final String? imageBase64;
  Message(this.text, this.user, {this.imageBase64});

  Map<String, dynamic> toJson() => {
        'text': text,
        'user': user,
        'image': imageBase64,
      };

  factory Message.fromJson(Map<String, dynamic> j) => Message(
        (j['text'] ?? '').toString(),
        j['user'] == true,
        imageBase64: j['image']?.toString(),
      );
}

class ChatSession {
  String id;
  String title;
  List<Message> messages;
  ChatSession(this.id, this.title, this.messages);

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'messages': messages.map((e) => e.toJson()).toList(),
      };

  factory ChatSession.fromJson(Map<String, dynamic> j) => ChatSession(
        (j['id'] ?? DateTime.now().microsecondsSinceEpoch.toString()).toString(),
        (j['title'] ?? 'Yangi suhbat').toString(),
        ((j['messages'] as List?) ?? [])
            .map((e) => Message.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}

class Api {
  static bool get configured => apiBaseUrl.trim().isNotEmpty;

  static Future<Map<String, dynamic>> post(
    String path,
    Map<String, dynamic> body, {
    String? token,
  }) async {
    if (!configured) {
      throw Exception('API server manzili sozlanmagan.');
    }

    final response = await http
        .post(
          Uri.parse('$apiBaseUrl$path'),
          headers: {
            'Content-Type': 'application/json',
            if (token != null && token.isNotEmpty)
              'Authorization': 'Bearer $token',
          },
          body: jsonEncode(body),
        )
        .timeout(const Duration(seconds: 60));

    Map<String, dynamic> data = {};
    try {
      final decoded = jsonDecode(response.body);
      if (decoded is Map) data = Map<String, dynamic>.from(decoded);
    } catch (_) {}

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data['error']?.toString() ?? 'Server xatosi');
    }
    return data;
  }
}

class MilliyAI extends StatefulWidget {
  const MilliyAI({super.key});

  @override
  State<MilliyAI> createState() => _MilliyAIState();
}

class _MilliyAIState extends State<MilliyAI> {
  bool light = false;
  bool sending = false;
  bool listening = false;
  String? token;
  String userName = 'Mehmon';
  String userRole = 'user';

  final input = TextEditingController();
  final speech = stt.SpeechToText();
  final picker = ImagePicker();

  List<ChatSession> sessions = [];
  int active = 0;
  String? image64;
  String? selectedFile;

  ChatSession get chat => sessions[active];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    input.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    token = p.getString('token');
    userName = p.getString('userName') ?? 'Mehmon';
    userRole = p.getString('role') ?? 'user';
    light = p.getBool('light') ?? false;

    final raw = p.getString('sessions');
    if (raw != null) {
      try {
        sessions = (jsonDecode(raw) as List)
            .map((e) => ChatSession.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      } catch (_) {}
    }

    if (sessions.isEmpty) {
      sessions = [
        ChatSession(
          DateTime.now().microsecondsSinceEpoch.toString(),
          'Yangi suhbat',
          [],
        )
      ];
    }

    if (mounted) setState(() {});
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(
      'sessions',
      jsonEncode(sessions.map((e) => e.toJson()).toList()),
    );
    await p.setBool('light', light);
  }

  Future<void> newChat() async {
    setState(() {
      sessions.insert(
        0,
        ChatSession(
          DateTime.now().microsecondsSinceEpoch.toString(),
          'Yangi suhbat',
          [],
        ),
      );
      active = 0;
      image64 = null;
      selectedFile = null;
    });
    await _save();
  }

  Future<void> deleteChat(int index) async {
    if (sessions.length == 1) {
      setState(() => sessions[0].messages.clear());
    } else {
      setState(() {
        sessions.removeAt(index);
        if (active >= sessions.length) active = sessions.length - 1;
      });
    }
    await _save();
  }

  Future<void> pickImage() async {
    final x = await picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 1600,
      imageQuality: 85,
    );
    if (x == null) return;
    final bytes = await x.readAsBytes();
    setState(() {
      image64 = base64Encode(bytes);
      selectedFile = null;
    });
  }

  Future<void> pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      withData: true,
      allowMultiple: false,
    );
    if (result == null || result.files.isEmpty) return;

    final file = result.files.single;
    setState(() {
      selectedFile = file.name;
      image64 = null;
    });
  }

  Future<void> voice() async {
    if (listening) {
      await speech.stop();
      if (mounted) setState(() => listening = false);
      return;
    }

    final ok = await speech.initialize(
      onStatus: (status) {
        if (status == 'done' && mounted) {
          setState(() => listening = false);
        }
      },
      onError: (_) {
        if (mounted) setState(() => listening = false);
      },
    );

    if (!ok) {
      _snack('Ovozli kiritish mavjud emas.');
      return;
    }

    setState(() => listening = true);
    await speech.listen(
      localeId: 'uz_UZ',
      onResult: (result) {
        if (result.recognizedWords.isNotEmpty) {
          input.text = result.recognizedWords;
          input.selection = TextSelection.fromPosition(
            TextPosition(offset: input.text.length),
          );
          if (result.finalResult && mounted) {
            setState(() => listening = false);
          }
        }
      },
    );
  }

  Future<void> send() async {
    final text = input.text.trim();
    if (text.isEmpty && image64 == null && selectedFile == null) return;
    if (sending) return;

    if (token == null || token!.isEmpty) {
      await _showAuth();
      if (token == null || token!.isEmpty) return;
    }

    final messageText = text.isEmpty ? 'Rasm/faylni tahlil qiling.' : text;

    setState(() {
      sending = true;
      chat.messages.add(
        Message(messageText, true, imageBase64: image64),
      );
      if (chat.title == 'Yangi suhbat') {
        chat.title = messageText.length > 28
            ? '${messageText.substring(0, 28)}...'
            : messageText;
      }
      input.clear();
    });
    await _save();

    try {
      final history = chat.messages
          .take(chat.messages.length - 1)
          .toList()
          .reversed
          .take(20)
          .toList()
          .reversed
          .map((m) => m.toJson())
          .toList();

      final result = await Api.post(
        '/v1/chat',
        {
          'message': messageText,
          'history': history,
          'image': image64,
          'file_name': selectedFile,
        },
        token: token,
      );

      final answer = (result['answer'] ?? 'AI javob qaytarmadi.').toString();
      if (mounted) {
        setState(() => chat.messages.add(Message(answer, false)));
      }
      await _save();
    } catch (e) {
      if (mounted) {
        setState(() {
          chat.messages.add(
            Message('Xatolik: ${e.toString().replaceFirst('Exception: ', '')}', false),
          );
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          sending = false;
          image64 = null;
          selectedFile = null;
        });
      }
      await _save();
    }
  }

  Future<void> _showAuth() async {
    if (!Api.configured) {
      _snack('API_BASE_URL hali sozlanmagan.');
      return;
    }

    final email = TextEditingController();
    final password = TextEditingController();
    final name = TextEditingController();
    bool register = false;
    bool busy = false;

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            Future<void> submit() async {
              if (email.text.trim().isEmpty || password.text.isEmpty) return;
              if (register && name.text.trim().isEmpty) return;

              setDialogState(() => busy = true);
              try {
                final result = await Api.post(
                  register ? '/v1/register' : '/v1/login',
                  register
                      ? {
                          'name': name.text.trim(),
                          'email': email.text.trim(),
                          'password': password.text,
                        }
                      : {
                          'email': email.text.trim(),
                          'password': password.text,
                        },
                );

                if (register) {
                  setDialogState(() => register = false);
                  _snack('Ro‘yxatdan o‘tildi. Endi kiring.');
                } else {
                  token = result['token']?.toString();
                  final user = result['user'];
                  if (user is Map) {
                    userName = user['name']?.toString() ?? 'Foydalanuvchi';
                    userRole = user['role']?.toString() ?? 'user';
                  }
                  final p = await SharedPreferences.getInstance();
                  await p.setString('token', token ?? '');
                  await p.setString('userName', userName);
                  await p.setString('role', userRole);
                  if (mounted) Navigator.pop(dialogContext);
                  if (mounted) setState(() {});
                }
              } catch (e) {
                if (mounted) _snack(e.toString().replaceFirst('Exception: ', ''));
              } finally {
                if (mounted) setDialogState(() => busy = false);
              }
            }

            return AlertDialog(
              title: Text(register ? 'Ro‘yxatdan o‘tish' : 'MILLIY AI ga kirish'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (register)
                      TextField(
                        controller: name,
                        decoration: const InputDecoration(labelText: 'Ism'),
                      ),
                    TextField(
                      controller: email,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(labelText: 'Email'),
                    ),
                    TextField(
                      controller: password,
                      obscureText: true,
                      decoration: const InputDecoration(labelText: 'Parol'),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: busy
                      ? null
                      : () => setDialogState(() => register = !register),
                  child: Text(register ? 'Kirish' : 'Ro‘yxatdan o‘tish'),
                ),
                FilledButton(
                  onPressed: busy ? null : submit,
                  child: busy
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : Text(register ? 'Yaratish' : 'Kirish'),
                ),
              ],
            );
          },
        );
      },
    );

    email.dispose();
    password.dispose();
    name.dispose();
  }

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text)),
    );
  }

  Future<void> _settings() async {
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Sozlamalar'),
        content: const Text(
          'MILLIY AI HTTPS orqali API serverga ulanadi. '
          'Maxfiy API kaliti APK ichiga joylanmaydi. '
          'Chat tarixi qurilmada saqlanadi.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Yopish'),
          ),
        ],
      ),
    );
  }

  Future<void> _profile() async {
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Profil'),
        content: Text(
          'Foydalanuvchi: $userName\n'
          'Rol: $userRole\n\n'
          'MILLIY AI • Donyor',
        ),
        actions: [
          if (userRole == 'admin')
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _adminPanel();
              },
              child: const Text('Admin panel'),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Yopish'),
          ),
        ],
      ),
    );
  }

  Future<void> _adminPanel() async {
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Admin panel'),
        content: const Text(
          'Admin rejimi yoqilgan.\n\n'
          'Serverdagi admin amallari faqat backend orqali autentifikatsiya '
          'qilinishi kerak. Bu APK maxfiy admin kalitlarini saqlamaydi.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Yopish'),
          ),
        ],
      ),
    );
  }

  Widget _empty() {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(30),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.auto_awesome, size: 64),
            SizedBox(height: 16),
            Text(
              'MILLIY AI',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
            ),
            SizedBox(height: 8),
            Text(
              'Murakkab savollar, rasm, ovoz va fayllar uchun '
              'aqlli o‘zbekcha yordamchi.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _bubble(Message m) {
    return Align(
      alignment: m.user ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 360),
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: m.user ? const Color(0xFF16A765) : const Color(0xFF171D25),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (m.imageBase64 != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Image.memory(
                  base64Decode(m.imageBase64!),
                  height: 180,
                  fit: BoxFit.contain,
                ),
              ),
            Text(m.text),
          ],
        ),
      ),
    );
  }

  Widget _drawer() {
    return SafeArea(
      child: Column(
        children: [
          const SizedBox(height: 20),
          const CircleAvatar(
            radius: 32,
            child: Icon(Icons.auto_awesome, size: 32),
          ),
          const SizedBox(height: 8),
          const Text(
            'MILLIY AI',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          Text(
            userName,
            style: const TextStyle(fontSize: 13),
          ),
          const Divider(height: 30),
          ListTile(
            leading: const Icon(Icons.add),
            title: const Text('Yangi suhbat'),
            onTap: () {
              Navigator.pop(context);
              newChat();
            },
          ),
          Expanded(
            child: ListView.builder(
              itemCount: sessions.length,
              itemBuilder: (c, i) => ListTile(
                selected: i == active,
                title: Text(
                  sessions[i].title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                leading: const Icon(Icons.chat_bubble_outline),
                onTap: () {
                  setState(() => active = i);
                  Navigator.pop(context);
                },
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => deleteChat(i),
                ),
              ),
            ),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.settings),
            title: const Text('Sozlamalar'),
            onTap: () {
              Navigator.pop(context);
              _settings();
            },
          ),
          ListTile(
            leading: const Icon(Icons.person_outline),
            title: const Text('Profil'),
            onTap: () {
              Navigator.pop(context);
              _profile();
            },
          ),
          if (userRole == 'admin')
            ListTile(
              leading: const Icon(Icons.admin_panel_settings_outlined),
              title: const Text('Admin panel'),
              onTap: () {
                Navigator.pop(context);
                _adminPanel();
              },
            ),
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text(
              '© MILLIY AI • Donyor',
              style: TextStyle(fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bg = light ? Colors.white : const Color(0xFF0B0F14);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Milliy AI',
      theme: ThemeData(
        useMaterial3: true,
        brightness: light ? Brightness.light : Brightness.dark,
        scaffoldBackgroundColor: bg,
      ),
      home: Scaffold(
        drawer: Drawer(child: _drawer()),
        appBar: AppBar(
          title: const Text(
            'MILLIY AI',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
          actions: [
            IconButton(
              tooltip: 'Yangi suhbat',
              onPressed: newChat,
              icon: const Icon(Icons.add_comment_outlined),
            ),
            IconButton(
              tooltip: 'Rejim',
              onPressed: () async {
                setState(() => light = !light);
                await _save();
              },
              icon: Icon(
                light ? Icons.dark_mode : Icons.light_mode,
              ),
            ),
          ],
        ),
        body: Column(
          children: [
            Expanded(
              child: chat.messages.isEmpty
                  ? _empty()
                  : ListView.builder(
                      padding: const EdgeInsets.all(14),
                      itemCount: chat.messages.length,
                      itemBuilder: (c, i) => _bubble(chat.messages[i]),
                    ),
            ),
            if (image64 != null || selectedFile != null)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Chip(
                    avatar: Icon(
                      image64 != null ? Icons.image : Icons.attach_file,
                    ),
                    label: Text(
                      image64 != null ? 'Rasm tayyor' : selectedFile!,
                    ),
                  ),
                ),
              ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: pickImage,
                      icon: const Icon(Icons.image_outlined),
                    ),
                    IconButton(
                      onPressed: pickFile,
                      icon: const Icon(Icons.attach_file),
                    ),
                    Expanded(
                      child: TextField(
                        controller: input,
                        minLines: 1,
                        maxLines: 5,
                        onSubmitted: (_) => send(),
                        decoration: const InputDecoration(
                          hintText: 'Savolingizni yozing...',
                          filled: true,
                          border: OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius: BorderRadius.all(
                              Radius.circular(22),
                            ),
                          ),
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: voice,
                      icon: Icon(
                        listening ? Icons.mic : Icons.mic_none,
                      ),
                    ),
                    const SizedBox(width: 2),
                    FloatingActionButton.small(
                      onPressed: sending ? null : send,
                      child: sending
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                              ),
                            )
                          : const Icon(Icons.arrow_upward),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
