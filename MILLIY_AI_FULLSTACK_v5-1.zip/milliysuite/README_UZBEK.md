# MILLIY AI — Full-stack v1

Bu loyiha Flutter APK + PHP/MySQL API uchun xavfsiz boshlang'ich sistema.

## Mobil ilova
- Chat va lokal tarix
- Yangi suhbat / o'chirish
- Dark/Light
- Rasm tanlash
- Ovozdan matn
- Fayl tanlash
- O'zbekcha UI
- API kalit APK ichida yo'q

## Backend
`backend/schema.sql` ni MySQL'da ishga tushiring. `backend/config.example.php` ni `config.php` qilib nusxalang va real DB/AI sozlamalarini faqat serverda kiriting.

AI endpoint OpenAI-compatible `chat/completions` formatidan foydalanadi. Bu provayderni keyinchalik almashtirishni osonlashtiradi.

## APK build
GitHub Actions workflow Flutter Android loyihasini yaratadi va `flutter build apk --release` bajaradi. APK artifact sifatida chiqadi.

GitHub Actions'da secretlar ishlatish tavsiya qilinadi. `API_BASE_URL` build vaqtida berilishi mumkin:
`flutter build apk --release --dart-define=API_BASE_URL=https://YOUR-DOMAIN/backend`

## Muhim
Haqiqiy AI, web search, vision va fayl parsing backendda alohida servis sifatida ulanishi kerak. Bu ZIP serverdagi maxfiy AI kalitini APKga joylamaydi. Web search/vision uchun tegishli server API kalitlari va provayderlar sozlanadi.
