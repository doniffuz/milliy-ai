import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

const apiBaseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: '');

void main() => runApp(const MilliyAI());

class Message {
  final String text;
  final bool user;
  final String? imageBase64;
  Message(this.text, this.user, {this.imageBase64});
  Map<String, dynamic> toJson() => {'text': text, 'user': user, 'image': imageBase64};
  factory Message.fromJson(Map<String, dynamic> j) => Message(j['text'] ?? '', j['user'] == true, imageBase64: j['image']);
}

class ChatSession {
  String id;
  String title;
  List<Message> messages;
  ChatSession(this.id, this.title, this.messages);
  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'messages': messages.map((e) => e.toJson()).toList()};
  factory ChatSession.fromJson(Map<String, dynamic> j) => ChatSession(j['id'], j['title'] ?? 'Yangi suhbat', (j['messages'] as List? ?? []).map((e) => Message.fromJson(Map<String,dynamic>.from(e))).toList());
}

class Api {
  static bool get configured => apiBaseUrl.trim().isNotEmpty;
  static Future<Map<String,dynamic>> post(String path, Map<String,dynamic> body, {String? token}) async {
    if (!configured) throw Exception('API ulanmagan. API_BASE_URL sozlanishi kerak.');
    final r = await http.post(Uri.parse('$apiBaseUrl$path'), headers: {'Content-Type':'application/json', if(token != null) 'Authorization':'Bearer $token'}, body: jsonEncode(body)).timeout(const Duration(seconds: 45));
    final data = jsonDecode(r.body);
    if (r.statusCode < 200 || r.statusCode >= 300) throw Exception(data['error'] ?? 'Server xatosi');
    return Map<String,dynamic>.from(data);
  }
}

class MilliyAI extends StatelessWidget {
  const MilliyAI({super.key});
  @override Widget build(BuildContext context) => MaterialApp(debugShowCheckedModeBanner:false, title:'Milliy AI', theme: ThemeData(useMaterial3:true, colorSchemeSeed:const Color(0xFF16A765), brightness:Brightness.dark), home:const ChatPage());
}

class ChatPage extends StatefulWidget { const ChatPage({super.key}); @override State<ChatPage> createState()=>_ChatPageState(); }
class _ChatPageState extends State<ChatPage> {
  final input=TextEditingController(); final picker=ImagePicker(); final speech=stt.SpeechToText();
  final sessions=<ChatSession>[]; int active=0; bool sending=false; bool listening=false; bool light=false; String? image64; String? selectedFile;
  @override void initState(){super.initState(); _load();}
  Future<void> _load() async { final p=await SharedPreferences.getInstance(); final raw=p.getString('sessions'); if(raw!=null){sessions.addAll((jsonDecode(raw) as List).map((e)=>ChatSession.fromJson(Map<String,dynamic>.from(e))));} if(sessions.isEmpty) sessions.add(ChatSession(DateTime.now().millisecondsSinceEpoch.toString(),'Yangi suhbat',[])); setState((){}); }
  Future<void> _save() async { final p=await SharedPreferences.getInstance(); await p.setString('sessions',jsonEncode(sessions.map((e)=>e.toJson()).toList())); }
  ChatSession get chat=>sessions[active];
  void newChat(){setState((){sessions.insert(0,ChatSession(DateTime.now().millisecondsSinceEpoch.toString(),'Yangi suhbat',[])); active=0;});_save();}
  void deleteChat(int i){if(sessions.length==1)return; setState((){sessions.removeAt(i); if(active>=sessions.length)active=sessions.length-1;});_save();}
  Future<void> pickImage() async { final x=await picker.pickImage(source:ImageSource.gallery,imageQuality:80); if(x==null)return; final bytes=await x.readAsBytes(); setState(()=>image64=base64Encode(bytes)); }
  Future<void> pickFile() async { final r=await FilePicker.platform.pickFiles(withData:true); if(r!=null)setState(()=>selectedFile=r.files.single.name); }
  Future<void> voice() async { if(listening){await speech.stop();setState(()=>listening=false);return;} final ok=await speech.initialize(onStatus:(s){if(s=='done')setState(()=>listening=false);}); if(!ok)return; setState(()=>listening=true); await speech.listen(onResult:(r){setState(()=>input.text=r.recognizedWords);}); }
  Future<void> send() async {
    final text=input.text.trim(); if((text.isEmpty && image64==null && selectedFile==null) || sending)return;
    final display=text.isEmpty?'Rasm/fayl yuborildi':text; final img=image64; final fileName=selectedFile;
    setState((){chat.messages.add(Message(display,true,imageBase64:img)); input.clear(); image64=null; selectedFile=null; sending=true;}); await _save();
    String answer;
    try {
      if(Api.configured){ final r=await Api.post('/v1/chat',{'message':text,'image_base64':img,'file_name':fileName,'history':chat.messages.take(20).map((e)=>e.toJson()).toList()}); answer=r['answer'] ?? 'Javob olinmadi.'; }
      else { answer='MILLIY AI demo rejimida. Haqiqiy AI, web, vision va fayl tahlilini yoqish uchun server API manzilini ulang.'; }
    } catch(e){answer='Ulanishda xatolik: ${e.toString().replaceFirst('Exception: ','')}';}
    setState((){chat.messages.add(Message(answer,false));sending=false; if(chat.title=='Yangi suhbat' && text.isNotEmpty)chat.title=text.length>30?text.substring(0,30):text;}); await _save();
  }
  @override Widget build(BuildContext context){ final bg=light?Colors.white:const Color(0xFF0B0F14); return Theme(data:Theme.of(context).copyWith(brightness:light?Brightness.light:Brightness.dark,scaffoldBackgroundColor:bg),child:Scaffold(drawer:Drawer(child:_drawer()),appBar:AppBar(title:const Text('MILLIY AI',style:TextStyle(fontWeight:FontWeight.w800)),actions:[IconButton(onPressed:newChat,icon:const Icon(Icons.add_comment_outlined)),IconButton(onPressed:()=>setState(()=>light=!light),icon:Icon(light?Icons.dark_mode:Icons.light_mode))]),body:Column(children:[Expanded(child:chat.messages.isEmpty?_empty():ListView.builder(padding:const EdgeInsets.all(14),itemCount:chat.messages.length,itemBuilder:(c,i)=>_bubble(chat.messages[i]))),if(image64!=null||selectedFile!=null)Padding(padding:const EdgeInsets.symmetric(horizontal:12),child:Align(alignment:Alignment.centerLeft,child:Chip(avatar:Icon(image64!=null?Icons.image:Icons.attach_file),label:Text(image64!=null?'Rasm tayyor':selectedFile!)))),SafeArea(top:false,child:Padding(padding:const EdgeInsets.fromLTRB(10,6,10,10),child:Row(children:[IconButton(onPressed:pickImage,icon:const Icon(Icons.image_outlined)),IconButton(onPressed:pickFile,icon:const Icon(Icons.attach_file)),Expanded(child:TextField(controller:input,minLines:1,maxLines:5,onSubmitted:(_)=>send(),decoration:const InputDecoration(hintText:'Savolingizni yozing...',filled:true,border:OutlineInputBorder(borderSide:BorderSide.none,borderRadius:BorderRadius.all(Radius.circular(22)))))),IconButton(onPressed:voice,icon:Icon(listening?Icons.mic:Icons.mic_none)),const SizedBox(width:2),FloatingActionButton.small(onPressed:sending?null:send,child:sending?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.arrow_upward))])))])); }
  Widget _empty()=>const Center(child:Padding(padding:EdgeInsets.all(30),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(Icons.auto_awesome,size:64),SizedBox(height:16),Text('Milliy AI',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900)),SizedBox(height:8),Text('Murakkab savollar, rasm, ovoz va fayllar uchun aqlli yordamchi.',textAlign:TextAlign.center)]));
  Widget _bubble(Message m)=>Align(alignment:m.user?Alignment.centerRight:Alignment.centerLeft,child:Container(constraints:const BoxConstraints(maxWidth:340),margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:m.user?const Color(0xFF16A765):const Color(0xFF171D25),borderRadius:BorderRadius.circular(18)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[if(m.imageBase64!=null)Padding(padding:const EdgeInsets.only(bottom:8),child:Image.memory(base64Decode(m.imageBase64!),height:180)),Text(m.text)])));
  Widget _drawer()=>SafeArea(child:Column(children:[const SizedBox(height:20),const CircleAvatar(radius:32,child:Icon(Icons.auto_awesome,size:32)),const SizedBox(height:8),const Text('MILLIY AI',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const Divider(height:30),ListTile(leading:const Icon(Icons.add),title:const Text('Yangi suhbat'),onTap:(){Navigator.pop(context);newChat();}),Expanded(child:ListView.builder(itemCount:sessions.length,itemBuilder:(c,i)=>ListTile(selected:i==active,title:Text(sessions[i].title,maxLines:1,overflow:TextOverflow.ellipsis),leading:const Icon(Icons.chat_bubble_outline),onTap:(){setState(()=>active=i);Navigator.pop(context);},trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()=>deleteChat(i)))),const Divider(),ListTile(leading:const Icon(Icons.settings),title:const Text('Sozlamalar'),onTap:(){Navigator.pop(context);showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Sozlamalar'),content:const Text('API server xavfsiz HTTPS orqali ulanadi. API kaliti APK ichida saqlanmaydi.'),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Yopish'))]));}),ListTile(leading:const Icon(Icons.person_outline),title:const Text('Profil'),onTap:(){Navigator.pop(context);showDialog(context:context,builder:(_)=>const AlertDialog(title:Text('Profil'),content:Text('MILLIY AI foydalanuvchisi'),));}),const Padding(padding:EdgeInsets.all(12),child:Text('© MILLIY AI • Donyor',style:TextStyle(fontSize:12))) ]));
}
