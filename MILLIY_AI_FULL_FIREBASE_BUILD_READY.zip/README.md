# MILLIY AI
Flutter + backend starter for the MILLIY AI application.

## Important
This project is structured for:
- Google sign-in
- user IDs
- AI chat
- image/file selection
- voice input/output hooks
- profile/settings
- server-authorized admin panel
- broadcast/video advertisement hooks
- mandatory app update configuration
- donation/support screen
- secure API architecture

Before production use, configure the backend URL and authentication/provider credentials. Secrets must not be hard-coded into the APK.

## Build
flutter pub get
flutter analyze
flutter build apk --release


## Firebase / Google Sign-In
`google-services.json` is included for Android package `com.example.milliy_ai`.
For Google Sign-In on a release APK, add the SHA-1 fingerprint of the signing certificate
to Firebase Console > Project settings > Your apps > Android > SHA certificate fingerprints.
The GitHub Actions workflow prepares the Android project with SDK 36, minSdk 24 and NDK 27.
