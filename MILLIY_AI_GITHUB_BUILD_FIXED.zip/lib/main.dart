import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:image_picker/image_picker.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;

const apiBaseUrl = String.fromEnvironment(
  'API_BASE_URL',
  defaultValue: 'https://YOUR-BACKEND.example/api',
);

void main() => runApp(const MilliyAI());

class MilliyAI extends StatelessWidget {
  const MilliyAI({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Milliy AI',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const AuthGate(),
    );
  }
}

class Api {
  static Future<Map<String, dynamic>> me(String token) async {
    final r = await http.get(Uri.parse('$apiBaseUrl/me'),
      headers: {'Authorization': 'Bearer $token'});
    if (r.statusCode != 200) throw Exception('Profil serverdan olinmadi');
    return jsonDecode(r.body);
  }

  static Future<String> chat({
    required String token,
    required String text,
    String? imagePath,
    String? filePath,
  }) async {
    final req = http.MultipartRequest('POST', Uri.parse('$apiBaseUrl/chat'));
    req.headers['Authorization'] = 'Bearer $token';
    req.fields['message'] = text;
    if (imagePath != null) req.files.add(await http.MultipartFile.fromPath('image', imagePath));
    if (filePath != null) req.files.add(await http.MultipartFile.fromPath('file', filePath));
    final res = await req.send();
    final body = await res.stream.bytesToString();
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('AI server xatosi: ${res.statusCode}');
    }
    return (jsonDecode(body)['answer'] ?? '').toString();
  }

  static Future<Map<String, dynamic>> appConfig() async {
    final r = await http.get(Uri.parse('$apiBaseUrl/app-config'));
    if (r.statusCode != 200) throw Exception('Config olinmadi');
    return jsonDecode(r.body);
  }
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override State<AuthGate> createState() => _AuthGateState();
}
class _AuthGateState extends State<AuthGate> {
  bool loading = true;
  String? token;
  Map<String, dynamic>? user;
  String? error;

  @override
  void initState() { super.initState(); _restore(); }

  Future<void> _restore() async {
    final p = await SharedPreferences.getInstance();
    final t = p.getString('token');
    if (t != null) {
      try {
        user = await Api.me(t);
        token = t;
      } catch (_) {
        await p.remove('token');
      }
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _googleLogin() async {
    setState(() { loading = true; error = null; });
    try {
      final account = await GoogleSignIn().signIn();
      if (account == null) throw Exception('Google kirish bekor qilindi');
      final auth = await account.authentication;
      final idToken = auth.idToken;
      if (idToken == null) throw Exception('Google token olinmadi');

      final r = await http.post(Uri.parse('$apiBaseUrl/auth/google'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id_token': idToken}));
      if (r.statusCode != 200) throw Exception('Google login serverda rad etildi');

      final data = jsonDecode(r.body);
      token = data['token'];
      user = Map<String, dynamic>.from(data['user']);
      final p = await SharedPreferences.getInstance();
      await p.setString('token', token!);
    } catch (e) {
      error = e.toString();
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (token != null && user != null) return Home(token: token!, user: user!);
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.auto_awesome, size: 76),
            const SizedBox(height: 12),
            const Text('MILLIY AI', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900)),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: loading ? null : _googleLogin,
              icon: const Icon(Icons.login),
              label: const Text('Google orqali kirish'),
            ),
            if (error != null) Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Text(error!, textAlign: TextAlign.center),
            ),
          ]),
        ),
      ),
    );
  }
}

class Home extends StatefulWidget {
  final String token;
  final Map<String, dynamic> user;
  const Home({super.key, required this.token, required this.user});
  @override State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final input = TextEditingController();
  final tts = FlutterTts();
  final speech = stt.SpeechToText();
  final picker = ImagePicker();
  final messages = <Map<String, String>>[];
  bool sending = false;
  bool listening = false;
  bool dark = false;
  String? imagePath;
  String? filePath;

  Future<void> send() async {
    final text = input.text.trim();
    if (text.isEmpty && imagePath == null && filePath == null) return;
    setState(() => sending = true);
    try {
      final answer = await Api.chat(
        token: widget.token, text: text,
        imagePath: imagePath, filePath: filePath,
      );
      setState(() {
        if (text.isNotEmpty) messages.add({'role': 'user', 'text': text});
        messages.add({'role': 'ai', 'text': answer});
        input.clear();
        imagePath = null;
        filePath = null;
      });
      await tts.speak(answer);
    } catch (e) {
      setState(() => messages.add({'role': 'ai', 'text': 'Xatolik: $e'}));
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  Future<void> pickImage() async {
    final x = await picker.pickImage(source: ImageSource.gallery);
    if (x != null) setState(() => imagePath = x.path);
  }

  Future<void> pickFile() async {
    final r = await FilePicker.platform.pickFiles();
    if (r != null && r.files.single.path != null) {
      setState(() => filePath = r.files.single.path);
    }
  }

  Future<void> voice() async {
    if (listening) {
      await speech.stop();
      setState(() => listening = false);
      return;
    }
    final ok = await speech.initialize();
    if (!ok) return;
    setState(() => listening = true);
    await speech.listen(onResult: (r) {
      input.text = r.recognizedWords;
      input.selection = TextSelection.collapsed(offset: input.text.length);
      if (r.finalResult) setState(() => listening = false);
    });
  }

  Future<void> settings() async {
    await showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(leading: const Icon(Icons.dark_mode), title: const Text('Dark / Light'),
          onTap: () { setState(() => dark = !dark); Navigator.pop(context); }),
        ListTile(leading: const Icon(Icons.favorite), title: const Text('Qo‘llab-quvvatlash'),
          onTap: () async {
            Navigator.pop(context);
            final uri = Uri.parse('https://example.com/donate');
            await launchUrl(uri, mode: LaunchMode.externalApplication);
          }),
        ListTile(leading: const Icon(Icons.person), title: Text('ID: ${widget.user['id'] ?? '-'}')),
      ])),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: ThemeData(
        useMaterial3: true,
        brightness: dark ? Brightness.dark : Brightness.light,
        colorSchemeSeed: Colors.indigo,
      ),
      child: Scaffold(
        appBar: AppBar(
          title: const Text('MILLIY AI', style: TextStyle(fontWeight: FontWeight.w800)),
          actions: [
            IconButton(onPressed: settings, icon: const Icon(Icons.settings)),
            IconButton(onPressed: () => setState(messages.clear), icon: const Icon(Icons.add_comment)),
          ],
        ),
        body: Column(children: [
          Expanded(
            child: messages.isEmpty
              ? const Center(child: Text('Savolingizni yozing yoki ovozli gapiring'))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: messages.length,
                  itemBuilder: (_, i) => Align(
                    alignment: messages[i]['role'] == 'user'
                      ? Alignment.centerRight : Alignment.centerLeft,
                    child: Card(child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Text(messages[i]['text'] ?? ''),
                    )),
                  ),
                ),
          ),
          if (imagePath != null || filePath != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Text(imagePath != null ? '🖼️ Rasm tanlandi' : '📎 Fayl tanlandi'),
            ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(children: [
                IconButton(onPressed: pickImage, icon: const Icon(Icons.image_outlined)),
                IconButton(onPressed: pickFile, icon: const Icon(Icons.attach_file)),
                Expanded(child: TextField(
                  controller: input,
                  minLines: 1,
                  maxLines: 5,
                  onSubmitted: (_) => send(),
                  decoration: const InputDecoration(
                    hintText: 'Savolingizni yozing...',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(22)),
                    ),
                  ),
                )),
                IconButton(
                  onPressed: voice,
                  icon: Icon(listening ? Icons.stop_circle : Icons.mic),
                ),
                const SizedBox(width: 2),
                FloatingActionButton.small(
                  onPressed: sending ? null : send,
                  child: sending
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.arrow_upward),
                ),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}
