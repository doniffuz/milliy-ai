MILLIY AI — 1-versiya

Bu loyiha Flutter uchun tayyorlangan boshlang'ich Android ilova.
Hozircha demo javob qaytaradi. Keyingi bosqichda o'z API serverimiz
va AI modelini ulaymiz.

Ishga tushirish:
1. Flutter o'rnatilgan bo'lsin.
2. Terminalda loyiha papkasiga kiring.
3. flutter pub get
4. flutter run

APK:
flutter build apk --release

APK odatda:
build/app/outputs/flutter-apk/app-release.apk

Eslatma:
AI API kalitini APK ichiga yozmaymiz. Keyingi bosqichda kalit serverda
saqlanadigan API arxitekturasini qilamiz.
